import {Component, Input, OnInit} from '@angular/core';
import {TopButton} from '../../app.component';
import {NumbsService} from '../../shared/numbs.service';

@Component({
  selector: 'app-top-element',
  templateUrl: './top-element.component.html',
  styleUrls: ['./top-element.component.styl']
})
export class TopElementComponent implements OnInit {
  @Input() topButtons: TopButton[] = [];

  constructor(public num: NumbsService) { }
  private doubleClick = [{id: 0, count: 0}];
  //=============================================
  
  ngOnInit() {
  }
  //--------------------------------

  closess(i: number) {


    if (this.doubleClick[0].id === i) {
      this.doubleClick[0].count +=  1;

      if (this.doubleClick[0].count > 0) {
        this.num.topButtons[i].visible = false;
        this.num.topButtons.splice(i, 1);

        // this.doubleClick[0].id = -1;
        // this.doubleClick[0].count = 0;

      }
    } else {
      this.doubleClick[0].id = i;


    }

  }


}
